# Django WEEK 5 - Making Queries (Advanced)

## Today's topics

1. Query Expression
2. Many-to-one Relationships
3. One-to-one Relationships
4. Many-to-many Relationships
